package com.example.GO_Outdoors_Payment;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.example.GO_Outdoors_Payment.Entity.PaymentEntity;

@SpringBootTest
class GoOutdoorsPaymentApplicationTests {
	@Test
	void mytest() {
		System.out.println("Testing in progress");
	}
// Get Operation
	@Test
	public void testgetUser() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Testcase is going on");
		final String baseUrl = "http://localhost:9006" + "/api6"+"/getcategory";
		URI uri = new URI(baseUrl);
		ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
		assertEquals(200, result.getStatusCodeValue());
	}
//Put Operation
	@Test
	public void testUpdateEmployee() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Testing employee update");
		final String baseUrl = "http://localhost:9006/api6/updatepayment/105";
		URI uri = new URI(baseUrl);
		PaymentEntity employeeToUpdate = new PaymentEntity(105, " Pay", "23-07-30");
		restTemplate.put(uri, employeeToUpdate);
	}
//	
	// Delete operation
			@Test
			public void testDeleteEmployee() throws URISyntaxException {
				RestTemplate restTemplate = new RestTemplate();
				System.out.println("Testing payment deletion");
				final String baseUrl = "http://localhost:9006/api6/deletepayment/102"; // Replace with your actual delete endpoint
				URI uri = new URI(baseUrl);
				restTemplate.delete(uri);
				// Optionally, verify that the delete was successful.
			}
//			// Post Operation
			@Test
			public void testAddEmployeeSuccess() throws URISyntaxException
			{
				RestTemplate restTemplate = new RestTemplate();
				final String baseUrl = "http://localhost:9006/api6/addcategory";
				URI uri = new URI(baseUrl);
				PaymentEntity user = new PaymentEntity(105, "google Pay", "23-09-28");
				HttpHeaders headers = new HttpHeaders();
				headers.set("X-COM-PERSIST", "true");
				HttpEntity<PaymentEntity> request = new HttpEntity<>(user, headers);
				ResponseEntity<String> result = restTemplate.postForEntity(uri, request, String.class);
				// Verify request succeed
				assertEquals(200, result.getStatusCodeValue());
			}
				
}
