package com.example.GO_Outdoors_Payment.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Payment")
public class PaymentEntity {
	@Id
int Payment_id;
String Payment_Method;
String Date;
public int getPayment_id() {
	return Payment_id;
}
public void setPayment_id(int payment_id) {
	Payment_id = payment_id;
}
public String getPayment_Method() {
	return Payment_Method;
}
public void setPayment_Method(String payment_Method) {
	Payment_Method = payment_Method;
}
public String getDate() {
	return Date;
}
public void setDate(String date) {
	Date = date;
}
public PaymentEntity(int payment_id, String payment_Method, String date) {
	super();
	Payment_id = payment_id;
	Payment_Method = payment_Method;
	Date = date;
}
public PaymentEntity() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "PaymentEntity [Payment_id=" + Payment_id + ", Payment_Method=" + Payment_Method + ", Date=" + Date + "]";
}


}
