package com.example.GO_Outdoors_Payment.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.GO_Outdoors_Payment.Entity.PaymentEntity;
import com.example.GO_Outdoors_Payment.Repository.PaymentRepository;



@CrossOrigin
@RestController
@RequestMapping("/api6")

public class PaymentController {
	@Autowired
	PaymentRepository PP;
	@PostMapping("/addcategory") // End Point
	public PaymentEntity createcategory(@RequestBody PaymentEntity category) {
		return PP.save(category);
	}
 
	@GetMapping("/getcategory")
	public List<PaymentEntity> getcategory() {
 
		return PP.findAll();
	}
	
	@DeleteMapping("/deletepayment/{Payment_id}")
	 
	public String get(@PathVariable("Payment_id") int Payment_id)
 
	{
 
		PP.deleteById(Payment_id);
 
		System.out.println("Payment details deleted\n");
 
		return "Is deleted";
 
	}
 
	@PutMapping("/updatepayment/{payment_id}") //
 
	public ResponseEntity<PaymentEntity> updatepayment(@PathVariable("payment_id") int payment_id, @RequestBody PaymentEntity paymentbypostman) {
 
		PaymentEntity payment = PP.findById(payment_id)
 
				.orElseThrow(() -> new RuntimeException("payment details not exist with id :" + payment_id));
 
		payment.setPayment_id(paymentbypostman.getPayment_id());
 
		payment.setPayment_Method(paymentbypostman.getPayment_Method());
 
		payment.setDate(paymentbypostman.getDate());
 
		PaymentEntity updatedPayment = PP.save(payment);
 
		return ResponseEntity.ok(updatedPayment);
 
	}
 

}
