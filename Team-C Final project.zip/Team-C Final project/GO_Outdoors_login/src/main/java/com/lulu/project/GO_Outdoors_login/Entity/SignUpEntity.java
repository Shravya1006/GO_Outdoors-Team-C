package com.lulu.project.GO_Outdoors_login.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Signup")
public class SignUpEntity {
	@Id
	String Name;
	int Mobile_num;
	String Email;
	String Password;
	String DOB;
	String State;
	String Country;
	int Pin;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getMobile_num() {
		return Mobile_num;
	}
	public void setMobile_num(int mobile_num) {
		Mobile_num = mobile_num;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
	public int getPin() {
		return Pin;
	}
	public void setPin(int pin) {
		Pin = pin;
	}
	public SignUpEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SignUpEntity(String name, int mobile_num, String email, String password, String dOB, String state, String country,
			int pin) {
		super();
		Name = name;
		Mobile_num = mobile_num;
		Email = email;
		Password = password;
		DOB = dOB;
		State = state;
		Country = country;
		Pin = pin;
	}
	@Override
	public String toString() {
		return "SignUp [Name=" + Name + ", Mobile_num=" + Mobile_num + ", Email=" + Email + ", Password=" + Password
				+ ", DOB=" + DOB + ", State=" + State + ", Country=" + Country + ", Pin=" + Pin + "]";
	}
	

}
