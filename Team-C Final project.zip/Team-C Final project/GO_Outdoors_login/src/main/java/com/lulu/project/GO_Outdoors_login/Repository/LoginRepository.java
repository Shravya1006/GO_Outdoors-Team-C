package com.lulu.project.GO_Outdoors_login.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lulu.project.GO_Outdoors_login.Entity.LoginEntity;

public interface LoginRepository extends JpaRepository<LoginEntity,Integer>{

}
