package com.lulu.project.GO_Outdoors_login.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lulu.project.GO_Outdoors_login.Entity.LoginEntity;
import com.lulu.project.GO_Outdoors_login.Repository.LoginRepository;

import jakarta.validation.Valid;

@CrossOrigin
@RestController
@RequestMapping("/api4/user")
public class LoginPageController {
	@Autowired
	LoginRepository lr;

	@GetMapping("/getuser")
	public List<LoginEntity> getJPQl() {

		return lr.findAll();

	}

	@PostMapping("/adduser")

	public LoginEntity createUser(@Valid @RequestBody LoginEntity prod) {

		return lr.save(prod);

	}

	@DeleteMapping("/user/{id}")

	public void delete(@PathVariable("id") Integer id) {

		lr.deleteById(id);

	}

	@PutMapping("/user/{id}")

	public LoginEntity updateUser(@PathVariable("id") Integer id, @RequestBody LoginEntity userBody) {


		LoginEntity newUser = lr.findById(id) 

				.orElseThrow(() -> new RuntimeException("Inventory not exist with id :" + id));

		newUser.setPassword(userBody.getPassword()); 

		newUser.setEmail(userBody.getEmail());

		return lr.save(newUser);

	}
	@GetMapping("/uservalid/{email}/{password}")
	public void getJPQL2(@PathVariable("email") String email,@PathVariable("password") String password) {
	//match with user name and password ,,,tuo can do it
		//Match all records and compare with above username and Password
		List<LoginEntity> rec=	lr.findAll();  //findAll()
		//stream API  ----  Simple approch iterarte
		for(LoginEntity u: rec) {
			//match
			System.out.println(u);
			System.out.println(u.getEmail());
			System.out.println(email);
			if(u.getEmail().equals(email)) {
		//if(u.getEmail().equals(email) )
		//&& u.getPassword().equals(password)  ) {
			System.out.println(" Valid- Authenticated");
				break;
		}else {
		System.out.println("Not Valid");		}
		}		
 
	}
}
