package com.lulu.project.GO_Outdoors_login;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
@EnableMethodSecurity
@EnableWebSecurity
@SpringBootApplication
public class GoOutdoorsLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoOutdoorsLoginApplication.class, args);
	}
	@Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http.csrf().disable()
                .authorizeHttpRequests()
                .requestMatchers("one","/api4/admin/admin").permitAll()
                .and()
                .authorizeHttpRequests().requestMatchers("/api4/admin/**")
                .authenticated().and().formLogin().and().build();
    }
	@Bean
    public SecurityFilterChain securityFilterChai(HttpSecurity http) throws Exception {
        return http.csrf().disable()
                .authorizeHttpRequests()
                .requestMatchers("one","/api4/user/user").permitAll()
                .and()
                .authorizeHttpRequests().requestMatchers("/api4/user/**")
                .authenticated().and().formLogin().and().build();
    }
	@Bean
    public SecurityFilterChain securityFilterCha(HttpSecurity http) throws Exception {
        return http.csrf().disable()
                .authorizeHttpRequests()
                .requestMatchers("one","/api4/signup/client").permitAll()
                .and()
                .authorizeHttpRequests().requestMatchers("/api4/signup/**")
                .authenticated().and().formLogin().and().build();
    }
}
