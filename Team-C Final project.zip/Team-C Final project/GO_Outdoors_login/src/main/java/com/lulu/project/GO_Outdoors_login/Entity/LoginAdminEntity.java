package com.lulu.project.GO_Outdoors_login.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;
@Entity
@Table(name="LoginAdmin")
public class LoginAdminEntity {
@Id
	int id;
	String Email;
	@Size(min = 8, max = 30, message = "password must be at least 8 characters long and less than 30 characters")
	String Password;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public LoginAdminEntity(int id, String email, String password) {
		super();
		this.id = id;
		Email = email;
		Password = password;
	}
	public LoginAdminEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "LoginEntity [id=" + id + ", Email=" + Email + ", Password=" + Password + "]";
	}
	
	
	
	

}

