package com.lulu.project.GO_Outdoors_login.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lulu.project.GO_Outdoors_login.Entity.LoginAdminEntity;
import com.lulu.project.GO_Outdoors_login.Repository.LoginAdminRepository;

import jakarta.validation.Valid;

@CrossOrigin
@RestController
@RequestMapping("/api4/admin")
public class LoginAdminController {
	@Autowired
	LoginAdminRepository  ar;
	@GetMapping("/admin")
	public List<LoginAdminEntity> getJPQl(){

		return ar.findAll();

		}
	@PostMapping("/admin")

	public LoginAdminEntity createUser(@Valid @RequestBody LoginAdminEntity prod) {

		return ar.save(prod);

	}
@DeleteMapping("/admin/{id}")

	public void delete(@PathVariable ("id") Integer id) {

	ar.deleteById(id);

	}
@PutMapping("/admin/{id}")



public LoginAdminEntity updateUser (@PathVariable ("id") Integer id, @RequestBody LoginAdminEntity userBody) {



	//Optional<LoginEntity> user1 = lr.findById(id);



	LoginAdminEntity newUser = ar.findById(id) //old data



			.orElseThrow(() -> new RuntimeException("Inventory not exist with id :" + id));



	newUser.setPassword(userBody.getPassword()); //the new data replaces the old data.



	newUser.setEmail(userBody.getEmail());



	return ar.save(newUser);
}

@GetMapping("/valid/{email}/{password}")
public void getJPQL2(@PathVariable("email") String email,@PathVariable("password") String password) {
//match with user name and password ,,,tuo can do it
	//Match all records and compare with above username and Password
	List<LoginAdminEntity> rec=	ar.findAll();  //findAll()
	//stream API  ----  Simple approch iterarte
	for(LoginAdminEntity u: rec) {
		//match
		System.out.println(u);
 
		if(u.getEmail().equals(email) && u.getPassword().equals(password)  ) {
			System.out.println(" Valid- Authenticated");
			break;
		}else {
			System.out.println("Not Valid");
		}
	}		
 
}
}

