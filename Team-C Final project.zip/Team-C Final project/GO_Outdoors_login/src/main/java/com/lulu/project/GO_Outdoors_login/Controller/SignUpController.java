package com.lulu.project.GO_Outdoors_login.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lulu.project.GO_Outdoors_login.Entity.LoginEntity;
import com.lulu.project.GO_Outdoors_login.Repository.LoginRepository;
@RestController
@RequestMapping("/api4/signup")
public class SignUpController {
	
	
		@Autowired
		LoginRepository lr;

		@GetMapping("/client")
		public List<LoginEntity> getJPQl() {

			return lr.findAll();

		}

		@PostMapping("/showuser")

		public LoginEntity createUser(@RequestBody LoginEntity prod) {

			return lr.save(prod);

		}

		@DeleteMapping("/deleteuser/{id}")

		public void delete(@PathVariable("id") Integer id) {

			lr.deleteById(id);

		}

		@PutMapping("/putuser/{id}")

		public LoginEntity updateUser(@PathVariable("id") Integer id, @RequestBody LoginEntity userBody) {


			LoginEntity newUser = lr.findById(id) 

					.orElseThrow(() -> new RuntimeException("Inventory not exist with id :" + id));

			newUser.setPassword(userBody.getPassword()); 

			newUser.setEmail(userBody.getEmail());

			return lr.save(newUser);

		}
}
