package com.lulu.project.GO_Outdoors_login;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.lulu.project.GO_Outdoors_login.Entity.LoginAdminEntity;



@SpringBootTest
class GoOutdoorsLoginApplicationTests {
	@Test
	void mytest() {
		System.out.println("Testing in progress");
	}
// Get Operation
	@Test
	public void testgetUser() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Testcase is going on");
		final String baseUrl = "http://localhost:9004" + "/api4/admin"+"/admin";
		URI uri = new URI(baseUrl);
		ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
		assertEquals(200, result.getStatusCodeValue());
	}
//Put Operation
	@Test
	public void testUpdateEmployee() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Testing employee update");
		final String baseUrl = "http://localhost:9004/api4/admin/admin/1004";
		URI uri = new URI(baseUrl);
		LoginAdminEntity employeeToUpdate = new LoginAdminEntity(1004, "poiuytre,@gmail.com", "zxcvbnm");
		restTemplate.put(uri, employeeToUpdate);
	}
//	
	// Delete operation
			@Test
			public void testDeleteEmployee() throws URISyntaxException {
				RestTemplate restTemplate = new RestTemplate();
				System.out.println("Testing Orders deletion");
				final String baseUrl = "http://localhost:9004/api4/admin/admin/1003"; // Replace with your actual delete endpoint
				URI uri = new URI(baseUrl);
				restTemplate.delete(uri);
				// Optionally, verify that the delete was successful.
			}
//			// Post Operation
			@Test
			public void testAddEmployeeSuccess() throws URISyntaxException
			{
				RestTemplate restTemplate = new RestTemplate();
				final String baseUrl = "http://localhost:9004/api4/admin/admin";
				URI uri = new URI(baseUrl);
				LoginAdminEntity user = new LoginAdminEntity(1004, "xcvbnm,@gmail.com", "zxchfhgvbnm");
				HttpHeaders headers = new HttpHeaders();
				headers.set("X-COM-PERSIST", "true");
				HttpEntity<LoginAdminEntity> request = new HttpEntity<>(user, headers);
				ResponseEntity<String> result = restTemplate.postForEntity(uri, request, String.class);
				// Verify request succeed
				assertEquals(200, result.getStatusCodeValue());
			}


}

	

	

	