package com.lulu.project.GO_Outdoors_login;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lulu.project.GO_Outdoors_login.Controller.SignUpController;
import com.lulu.project.GO_Outdoors_login.Entity.LoginEntity;
import com.lulu.project.GO_Outdoors_login.Repository.LoginRepository;

@WebMvcTest(SignUpController.class)
class GoOutdoorsSignUpTests {

	  @MockBean
	    private LoginRepository loginRepository;
	 
	    @Autowired
	    private MockMvc mockMvc;
	 
	    @Autowired
	    private ObjectMapper objectMapper;
	 //Get
	    @Test
	    void testGetAllClients() throws Exception {
	        List<LoginEntity> clientList = new ArrayList<>();
	        // Add sample client entities to the list
	 
	        when(loginRepository.findAll()).thenReturn(clientList);
	 
	        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/api4/signup/client")
	                .contentType(MediaType.APPLICATION_JSON))
	                .andReturn();
	 
	        int status = result.getResponse().getStatus();
	        assertEquals(200, status);
	 
	        LoginEntity[] responseClients = objectMapper.readValue(result.getResponse().getContentAsString(), LoginEntity[].class);
	        assertNotNull(responseClients);
	        // Add assertions based on your application logic
	    }
	 //Post
	    @Test
	    void testCreateUser() throws Exception {
	        LoginEntity user = new LoginEntity();
	        user.setId(1);
	        user.setEmail("user@example.com");
	        user.setPassword("user123");
	 
	        when(loginRepository.save(any(LoginEntity.class))).thenReturn(user);
	 
	        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post("/api4/signup/showuser")
	                .contentType(MediaType.APPLICATION_JSON)
	                .content(objectMapper.writeValueAsString(user)))
	                .andReturn();
	 
	        int status = result.getResponse().getStatus();
	        assertEquals(200, status);
	 
	        LoginEntity responseUser = objectMapper.readValue(result.getResponse().getContentAsString(), LoginEntity.class);
	        assertNotNull(responseUser.getId());
	        // Add assertions based on your application logic
	    }
	 //Delete
	    @Test
	    void testDeleteUser() throws Exception {
	        doNothing().when(loginRepository).deleteById(1);
	 
	        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.delete("/api4/signup/deleteuser/{id}", 1)
	                .contentType(MediaType.APPLICATION_JSON))
	                .andReturn();
	 
	        int status = result.getResponse().getStatus();
	        assertEquals(200, status);
	        // Add assertions based on your application logic
	    }
	 //Put
	    @Test
	    void testUpdateUser() throws Exception {
	        LoginEntity userToUpdate = new LoginEntity();
	        userToUpdate.setId(1);
	        userToUpdate.setEmail("updated_user@example.com");
	        userToUpdate.setPassword("updated_user123");
	 
	        when(loginRepository.findById(1)).thenReturn(Optional.of(new LoginEntity()));
	 
	        when(loginRepository.save(any(LoginEntity.class))).thenReturn(userToUpdate);
	 
	        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.put("/api4/signup/putuser/{id}", 1)
	                .contentType(MediaType.APPLICATION_JSON)
	                .content(objectMapper.writeValueAsString(userToUpdate)))
	                .andReturn();
	 
	        int status = result.getResponse().getStatus();
	        assertEquals(200, status);
	 
	        LoginEntity responseUser = objectMapper.readValue(result.getResponse().getContentAsString(), LoginEntity.class);
	        assertNotNull(responseUser.getId());
	        // Add assertions based on your application logic
	    }

}


