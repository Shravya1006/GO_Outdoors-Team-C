package com.lulu.project.GO_Outdoors_login;

import static org.junit.jupiter.api.Assertions.*;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.lulu.project.GO_Outdoors_login.Entity.LoginEntity;

class GoOutdoorsLoginPageTests {

	@Test
	void mytest() {
		System.out.println("Testing in progress");
	}
// Get Operation
	@Test
	public void testgetUser() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Testcase is going on");
		final String baseUrl = "http://localhost:9004" + "/api4/user"+"/getuser";
		URI uri = new URI(baseUrl);
		ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
		assertEquals(200, result.getStatusCodeValue());
	}
//Put Operation
	@Test
	public void testUpdateEmployee() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Testing employee update");
		final String baseUrl = "http://localhost:9004/api4/user/user/808";
		URI uri = new URI(baseUrl);
		LoginEntity employeeToUpdate = new LoginEntity(808, "pokjnbszx@gmail.com", "iuytrews");
		restTemplate.put(uri, employeeToUpdate);
	}
//	
	// Delete operation
			@Test
			public void testDeleteEmployee() throws URISyntaxException {
				RestTemplate restTemplate = new RestTemplate();
				System.out.println("Testing Orders deletion");
				final String baseUrl = "http://localhost:9004/api4/user/user/707"; // Replace with your actual delete endpoint
				URI uri = new URI(baseUrl);
				restTemplate.delete(uri);
				// Optionally, verify that the delete was successful.
			}
//			// Post Operation
			@Test
			public void testAddEmployeeSuccess() throws URISyntaxException
			{
				RestTemplate restTemplate = new RestTemplate();
				final String baseUrl = "http://localhost:9004/api4/user/adduser";
				URI uri = new URI(baseUrl);
				LoginEntity user = new LoginEntity(808, "pokjnbszx@gmail.com", "oiuyhgvcxsw");
				HttpHeaders headers = new HttpHeaders();
				headers.set("X-COM-PERSIST", "true");
				HttpEntity<LoginEntity> request = new HttpEntity<>(user, headers);
				ResponseEntity<String> result = restTemplate.postForEntity(uri, request, String.class);
				// Verify request succeed
				assertEquals(200, result.getStatusCodeValue());
			}	
}


