package com.example.GO_Outdoors_ReturnsManagement;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;


import com.example.GO_Outdoors_ReturnsManagement.Entity.ReturnsManagementEntity;

@SpringBootTest
class GoOutdoorsReturnsManagementApplicationTests {
	@Test
	void contextLoads() {
	}
	@Test
			void mytest() {
				System.out.println("Testing in progress");
			}
		// Get Operation
			@Test
			public void testgetUser() throws URISyntaxException {
				RestTemplate restTemplate = new RestTemplate();
				System.out.println("Testcase is going on");
				final String baseUrl = "http://localhost:9007" + "/api7/getreturns";
				URI uri = new URI(baseUrl);
				ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
				assertEquals(200, result.getStatusCodeValue());
			}
		//Put Operation
			@Test
			public void testUpdateEmployee() throws URISyntaxException {
				RestTemplate restTemplate = new RestTemplate();
				System.out.println("Testing employee update");
				final String baseUrl = "http://localhost:9007/api7/updatereturns/114";
				URI uri = new URI(baseUrl);
				ReturnsManagementEntity returnsToUpdate = new ReturnsManagementEntity(114, " Did not like the fitting", "29-11-2023");
				restTemplate.put(uri, returnsToUpdate);
			}
			// Delete operation
					@Test
					public void testDeleteEmployee() throws URISyntaxException {
						RestTemplate restTemplate = new RestTemplate();
						System.out.println("Testing payment deletion");
						final String baseUrl = "http://localhost:9007/api7/deletereturns/112"; // Replace with your actual delete endpoint
						URI uri = new URI(baseUrl);
						restTemplate.delete(uri);
						// Optionally, verify that the delete was successful.
					}

					// Post Operation
					@Test
					public void testAddEmployeeSuccess() throws URISyntaxException
						{
						RestTemplate restTemplate = new RestTemplate();
						final String baseUrl = "http://localhost:9007/api7/addreturns";
						URI uri = new URI(baseUrl);
						ReturnsManagementEntity user = new ReturnsManagementEntity(114, "Damaged Item", "24-11-23");
						HttpHeaders headers = new HttpHeaders();
						headers.set("X-COM-PERSIST", "true");
						HttpEntity<ReturnsManagementEntity> request = new HttpEntity<>(user, headers);
						ResponseEntity<String> result = restTemplate.postForEntity(uri, request, String.class);
						// Verify request succeed
						assertEquals(200, result.getStatusCodeValue());
						}

 
}
