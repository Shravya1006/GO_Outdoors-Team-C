package com.example.GO_Outdoors_ReturnsManagement.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.GO_Outdoors_ReturnsManagement.Entity.ReturnsManagementEntity;
import com.example.GO_Outdoors_ReturnsManagement.Repository.ReturnsManagementRepository;


@CrossOrigin
@RestController
@RequestMapping("/api7")
public class ReturnsManagementController {
	@Autowired
	 
	ReturnsManagementRepository RP;
 
	
 
	
 
	@PostMapping("/addreturns") // End Point
	ReturnsManagementEntity createReturns(@RequestBody ReturnsManagementEntity returns) {
 
		return RP.save(returns);
 
	}
 
	@GetMapping("/getreturns")
 
	public List<ReturnsManagementEntity> getreturns() {
 
		return RP.findAll();
 
	}
 
	@DeleteMapping("/deletereturns/{return_id}")
 
	public String get(@PathVariable("return_id") int return_id)
 
	{
 
		RP.deleteById(return_id);
 
		System.out.println("Returns details deleted\n");
 
		return "Is deleted";
 
	}
 
	@PutMapping("/updatereturns/{return_id}") //
 
	public ResponseEntity<ReturnsManagementEntity> updateReturns(@PathVariable("return_id") int return_id,
 
			@RequestBody ReturnsManagementEntity returnsbypostman) {
 
		ReturnsManagementEntity returns = RP.findById(return_id)
 
				.orElseThrow(() -> new RuntimeException("Return details not exist with id :" + return_id));
 
		returns.setReturn_id(returnsbypostman.getReturn_id());
 
		returns.setReason(returnsbypostman.getReason());
 
		returns.setReturn_date(returnsbypostman.getReturn_date());
 
		ReturnsManagementEntity updatedReturns = RP.save(returns);
 
		return ResponseEntity.ok(updatedReturns);
 
	}
 
 
}
 



