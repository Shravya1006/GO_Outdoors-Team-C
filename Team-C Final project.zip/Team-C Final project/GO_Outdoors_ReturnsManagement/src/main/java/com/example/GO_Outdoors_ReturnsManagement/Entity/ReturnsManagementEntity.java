package com.example.GO_Outdoors_ReturnsManagement.Entity;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name="Returns")
public class ReturnsManagementEntity {
	@Id
	int return_id;
	public ReturnsManagementEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ReturnsManagementEntity(int return_id, String reason, String return_date) {
		super();
		this.return_id = return_id;
		this.reason = reason;
		this.return_date = return_date;
	}
	@Override
	public String toString() {
		return "ReturnsManagementEntity [return_id=" + return_id + ", reason=" + reason + ", return_date=" + return_date
				+ "]";
	}
	public int getReturn_id() {
		return return_id;
	}
	public void setReturn_id(int return_id) {
		this.return_id = return_id;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getReturn_date() {
		return return_date;
	}
	public void setReturn_date(String return_date) {
		this.return_date = return_date;
	}
	String reason;
	String return_date;
	
	

}
