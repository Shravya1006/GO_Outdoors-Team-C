package com.example.GO_Outdoors_ReturnsManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
@EnableMethodSecurity
@EnableWebSecurity
@SpringBootApplication
public class GoOutdoorsReturnsManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoOutdoorsReturnsManagementApplication.class, args);
	}
	@Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http.csrf().disable()
                .authorizeHttpRequests()
                .requestMatchers("one","/api7/addreturns").permitAll()
                .and()
                .authorizeHttpRequests().requestMatchers("/api7/**")
                .authenticated().and().formLogin().and().build();
    }

}
