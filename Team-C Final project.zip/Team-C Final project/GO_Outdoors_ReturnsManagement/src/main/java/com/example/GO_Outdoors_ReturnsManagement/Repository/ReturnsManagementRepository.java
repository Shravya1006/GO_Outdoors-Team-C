package com.example.GO_Outdoors_ReturnsManagement.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.GO_Outdoors_ReturnsManagement.Entity.ReturnsManagementEntity;

public interface ReturnsManagementRepository  extends JpaRepository<ReturnsManagementEntity, Integer>{

}
