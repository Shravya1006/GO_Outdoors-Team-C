package com.lulu.Lulu_02_security.Lulu_02_security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lulu02SecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lulu02SecurityApplication.class, args);
	}

}
