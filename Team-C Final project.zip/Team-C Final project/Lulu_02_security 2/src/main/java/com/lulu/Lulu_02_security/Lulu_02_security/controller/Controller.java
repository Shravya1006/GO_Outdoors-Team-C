package com.lulu.Lulu_02_security.Lulu_02_security.controller;



import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class Controller {
	
	@GetMapping("/one")
	public String One() {
		return "One success";
	}
	
	@GetMapping("/two")
	public String Two() {
		return "Two success";
	}
	
	@GetMapping("/three")
	public String Three() {
		return "Three success";
	}
	

}
