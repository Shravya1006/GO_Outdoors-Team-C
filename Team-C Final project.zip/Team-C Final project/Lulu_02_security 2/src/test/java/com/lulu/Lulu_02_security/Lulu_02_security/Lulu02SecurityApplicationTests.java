package com.lulu.Lulu_02_security.Lulu_02_security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lulu02SecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
