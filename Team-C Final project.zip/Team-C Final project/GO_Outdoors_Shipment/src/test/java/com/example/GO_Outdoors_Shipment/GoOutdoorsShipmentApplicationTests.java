package com.example.GO_Outdoors_Shipment;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.example.GO_Outdoors_Shipment.Entity.ShipmentEntity;

@SpringBootTest
class GoOutdoorsShipmentApplicationTests {
@Test
void contextLoads() {
}
@Test
void mytest() {
System.out.println("Testing in progress");
}
//Get Operation
@Test
	public void testgetUser() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Testcase is going on");
		final String baseUrl = "http://localhost:9009" + "/api9"+"/shipment/getshipment";
		URI uri = new URI(baseUrl);
		ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
		assertEquals(200, result.getStatusCodeValue());
}


//		// Delete operation
		@Test
			public void testDeleteCustomer() throws URISyntaxException {
			RestTemplate restTemplate = new RestTemplate();
			System.out.println("Testing Shipment deletion");
			final String baseUrl = "http://localhost:9009/api9/shipment/shipment/220"; // Replace with your actual delete endpoint
			URI uri = new URI(baseUrl);
			restTemplate.delete(uri);
			// Optionally, verify that the delete was successful.
		}
		// Post Operation
	@Test
	public void testAddCustomerSuccess() throws URISyntaxException
	{
	RestTemplate restTemplate = new RestTemplate();
		final String baseUrl = "http://localhost:9009/api9/shipment/addshipment";
		URI uri = new URI(baseUrl);
		ShipmentEntity user = new ShipmentEntity(408, "Bangalore", 8778);
		HttpHeaders headers = new HttpHeaders();
		headers.set("X-COM-PERSIST", "true");
		HttpEntity<ShipmentEntity> request = new HttpEntity<>(user, headers);
		ResponseEntity<String> result = restTemplate.postForEntity(uri, request, String.class);
		// Verify request succeed
		assertEquals(200, result.getStatusCodeValue());
	}
	//Put Operation
	@Test
	public void testUpdateCustomer() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Testing Shipment update");
		final String baseUrl = "http://localhost:9009"+"/api9/shipment"+"/updateshipment/123";
		URI uri = new URI(baseUrl);
		ShipmentEntity ShipmentToUpdate = new ShipmentEntity(123, "mysore", 123);
		restTemplate.put(uri, ShipmentToUpdate);
	}
}

	