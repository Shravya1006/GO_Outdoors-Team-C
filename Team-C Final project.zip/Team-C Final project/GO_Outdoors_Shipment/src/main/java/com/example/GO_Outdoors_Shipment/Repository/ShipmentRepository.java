package com.example.GO_Outdoors_Shipment.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.GO_Outdoors_Shipment.Entity.ShipmentEntity;

public interface ShipmentRepository extends JpaRepository<ShipmentEntity, Integer>{

}
