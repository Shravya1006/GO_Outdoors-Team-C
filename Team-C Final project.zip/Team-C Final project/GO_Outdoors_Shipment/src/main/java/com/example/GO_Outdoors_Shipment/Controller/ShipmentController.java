package com.example.GO_Outdoors_Shipment.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.GO_Outdoors_Shipment.Entity.ShipmentEntity;
import com.example.GO_Outdoors_Shipment.Repository.ShipmentRepository;

@CrossOrigin
@RestController
@RequestMapping("/api9/shipment")
public class ShipmentController {
	@Autowired
	ShipmentRepository SP;
 
	 
	@GetMapping("/getshipment")
 
	public List<ShipmentEntity> getreturns() {
 
		return SP.findAll();
 
	}
	 
 
	
 
	@PostMapping("/addshipment") // End Point
	ShipmentEntity createReturns(@RequestBody ShipmentEntity returns) {
 
		return SP.save(returns);
 
	}

	@DeleteMapping("/shipment/{shipment_id}")
	public String get(@PathVariable("shipment_id") int shipment_id) {
	    SP.deleteById(shipment_id);
	    System.out.println("Shipment details deleted\n");
	    return "Is deleted";
	}
 
	@PutMapping("/updateshipment/{Shipment_id}")
	public ResponseEntity<ShipmentEntity> updateShipment(
	        @PathVariable("Shipment_id") Integer Shipment_id,
	        @RequestBody ShipmentEntity Shipmentbypostman) {
	    ShipmentEntity Shipment = SP.findById(Shipment_id)
	            .orElseThrow(() -> new RuntimeException("Shipment details not exist with id :" + Shipment_id));

	    Shipment.setShipment_address(Shipmentbypostman.getShipment_address());
	    Shipment.setOrder_id(Shipmentbypostman.getOrder_id());
	    ShipmentEntity updatedShipment = SP.save(Shipment);

	    return ResponseEntity.ok(updatedShipment);
	}

}
