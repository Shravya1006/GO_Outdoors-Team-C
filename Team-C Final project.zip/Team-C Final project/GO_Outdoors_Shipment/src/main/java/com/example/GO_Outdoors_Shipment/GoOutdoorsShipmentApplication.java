package com.example.GO_Outdoors_Shipment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
@EnableMethodSecurity
@EnableWebSecurity
@SpringBootApplication
public class GoOutdoorsShipmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoOutdoorsShipmentApplication.class, args);
	}
	@Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http.csrf().disable()
                .authorizeHttpRequests()
                .requestMatchers("one","/api9/shipment/addshipment").permitAll()
                .and()
                .authorizeHttpRequests().requestMatchers("/api9/shipment/**")
                .authenticated().and().formLogin().and().build();
    }

}
