package com.example.GO_Outdoors_Shipment.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Shipment")
public class ShipmentEntity {
	@Id
	int Shipment_id;
	
	String Shipment_address;
	int Order_id;
	public int getShipment_id() {
		return Shipment_id;
	}
	public void setShipment_id(int shipment_id) {
		Shipment_id = shipment_id;
	}
	public String getShipment_address() {
		return Shipment_address;
	}
	public void setShipment_address(String shipment_address) {
		Shipment_address = shipment_address;
	}
	public int getOrder_id() {
		return Order_id;
	}
	public void setOrder_id(int order_id) {
		Order_id = order_id;
	}
	public ShipmentEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ShipmentEntity(int shipment_id, String shipment_address, int order_id) {
		super();
		Shipment_id = shipment_id;
		Shipment_address = shipment_address;
		Order_id = order_id;
	}
	@Override
	public String toString() {
		return "ShipmentEntity [Shipment_id=" + Shipment_id + ", Shipment_address=" + Shipment_address + ", Order_id="
				+ Order_id + "]";
	}
}
