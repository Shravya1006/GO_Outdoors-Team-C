package com.example.GO_OUTDOORS_Catalogue.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.GO_OUTDOORS_Catalogue.Entity.CategoryEntity;
import com.example.GO_OUTDOORS_Catalogue.Repository.CategoryRepository;

@CrossOrigin
@RestController
@RequestMapping("/api2/category")
public class CategoryController {
	@Autowired
	CategoryRepository CR;
 
	@PostMapping("/addcategory") // End Point
	public CategoryEntity createcategory(@RequestBody CategoryEntity category) {
		return CR.save(category);
	}
 
	@GetMapping("/getcategory")
	public List<CategoryEntity> getcategory() {
 
		return CR.findAll();
	}
 
	// DeLETE data //
 
	@DeleteMapping("/deletecategory/{category_id}")
	public String get(@PathVariable("category_id") int category_id) {
		CR.deleteById(category_id);
		System.out.println("Record 1 got deleted");
		return "Is deleted"; // select * from Order;
	}
 
	// Delete multiple data
	@DeleteMapping("/deletecategories/{category_id1}/{category_id2}")
	public String deleteCategories(@PathVariable("category_id1") int category_id1,
			@PathVariable("category_id2") int category_id2) {
		CR.deleteById(category_id1);
		CR.deleteById(category_id2);
		System.out.println("Category 1 got Deleted");
		System.out.println("Category 2 got Deleted");
		return "Is deleted";
 
	}
 
	// Update data//
 
	@PutMapping("/updatecategory/{category_id}") //
 
	public ResponseEntity<CategoryEntity> updateCategory(@PathVariable("category_id") int category_id,
			@RequestBody CategoryEntity categorybypostman) {
 
		CategoryEntity category = CR.findById(category_id)
 
				.orElseThrow(() -> new RuntimeException("Category not exist with id :" + category_id));
 
		category.setCategory_id(categorybypostman.getCategory_id());
 
		category.setCategory_name(categorybypostman.getCategory_name());
 
		CategoryEntity updatedCategory = CR.save(category);
 
		return ResponseEntity.ok(updatedCategory);
 
	}

}
