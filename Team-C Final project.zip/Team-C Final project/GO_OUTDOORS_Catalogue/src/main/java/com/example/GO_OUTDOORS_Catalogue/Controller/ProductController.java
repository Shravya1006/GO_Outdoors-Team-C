package com.example.GO_OUTDOORS_Catalogue.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.GO_OUTDOORS_Catalogue.Entity.ProductEntity;
import com.example.GO_OUTDOORS_Catalogue.Repository.ProductRepository;



@CrossOrigin
@RestController
@RequestMapping("/api2/Product")

public class ProductController {
	@Autowired
	ProductRepository PR;
 
	@PostMapping("/addproducts") // End Point
	public ProductEntity createproducts(@RequestBody ProductEntity products) {
		return PR.save(products);
	}
 
	@GetMapping("/getproducts")
	public List<ProductEntity> getproducts() {
 
		return PR.findAll();
	}
 
	
 
	// DeLETE data //
 
	@DeleteMapping("/deleteproducts/{product_id}")
 
	public String get(@PathVariable("product_id") int product_id) {
 
		PR.deleteById(product_id);
 
		System.out.println("Record 1 got deleted");
 
		return "Is deleted"; // select * from Order;
 
	}
 
	
 
	@PutMapping("/updateproducts/{product_id}") //
 
	public ResponseEntity<ProductEntity> updateProducts(@PathVariable("product_id") int product_id,
			@RequestBody ProductEntity productsbypostman) {
 
		ProductEntity products = PR.findById(product_id)
 
				.orElseThrow(() -> new RuntimeException("Product not exist with id :" + product_id));
 
		products.setProduct_id(productsbypostman.getProduct_id());
		products.setProduct_name(productsbypostman.getProduct_name());
		products.setPrice(productsbypostman.getPrice());
		products.setDiscount(productsbypostman.getDiscount());
 
		ProductEntity updatedProducts = PR.save(products);
		return ResponseEntity.ok(updatedProducts);
	}
 
	
 

}
