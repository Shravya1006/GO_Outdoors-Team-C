package com.example.GO_OUTDOORS_Catalogue.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.GO_OUTDOORS_Catalogue.Entity.CategoryEntity;



public interface CategoryRepository extends JpaRepository<CategoryEntity,Integer>{

}
