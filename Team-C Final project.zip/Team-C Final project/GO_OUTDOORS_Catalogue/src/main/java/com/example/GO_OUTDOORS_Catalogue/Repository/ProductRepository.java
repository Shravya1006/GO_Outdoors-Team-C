package com.example.GO_OUTDOORS_Catalogue.Repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.example.GO_OUTDOORS_Catalogue.Entity.ProductEntity;

public interface ProductRepository extends JpaRepository<ProductEntity,Integer>{

}
