package com.example.GO_OUTDOORS_Catalogue.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Product")
public class ProductEntity {
	@Id
int Product_id;
String Product_name;
float price;
float Discount;
int Quantity_instock;
String Manufacturer;
public int getProduct_id() {
	return Product_id;
}
public void setProduct_id(int product_id) {
	Product_id = product_id;
}
public String getProduct_name() {
	return Product_name;
}
public void setProduct_name(String product_name) {
	Product_name = product_name;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
public float getDiscount() {
	return Discount;
}
public void setDiscount(float discount) {
	Discount = discount;
}
public int getQuantity_instock() {
	return Quantity_instock;
}
public void setQuantity_instock(int quantity_instock) {
	Quantity_instock = quantity_instock;
}
public String getManufacturer() {
	return Manufacturer;
}
public void setManufacturer(String manufacturer) {
	Manufacturer = manufacturer;
}
public ProductEntity(int product_id, String product_name, float price, float discount, int quantity_instock,
		String manufacturer) {
	super();
	Product_id = product_id;
	Product_name = product_name;
	this.price = price;
	Discount = discount;
	Quantity_instock = quantity_instock;
	Manufacturer = manufacturer;
}
public ProductEntity() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "ProductEntity [Product_id=" + Product_id + ", Product_name=" + Product_name + ", price=" + price
			+ ", Discount=" + Discount + ", Quantity_instock=" + Quantity_instock + ", Manufacturer=" + Manufacturer
			+ "]";
}


}
