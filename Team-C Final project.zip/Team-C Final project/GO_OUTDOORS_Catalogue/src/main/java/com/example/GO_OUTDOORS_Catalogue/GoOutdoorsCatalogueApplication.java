package com.example.GO_OUTDOORS_Catalogue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.servlet.configuration.EnableWebMvcSecurity;
import org.springframework.security.web.SecurityFilterChain;
@EnableMethodSecurity
@SpringBootApplication
@EnableWebSecurity
public class GoOutdoorsCatalogueApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoOutdoorsCatalogueApplication.class, args);
	}
	@Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http.csrf().disable()
                .authorizeHttpRequests()
                .requestMatchers("one","/api2/category/addproducts").permitAll()
                .and()
                .authorizeHttpRequests().requestMatchers("/api2/category/**")
                .authenticated().and().formLogin().and().build();
    }
	@Bean
    public SecurityFilterChain securityFilterChai(HttpSecurity http) throws Exception {
        return http.csrf().disable()
                .authorizeHttpRequests()
                .requestMatchers("one","/api2/Products/addproducts").permitAll()
                .and()
                .authorizeHttpRequests().requestMatchers("/api2/Products/**")
                .authenticated().and().formLogin().and().build();
    }

}
