package com.example.GO_Outdoors_Orders;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;


import com.example.GO_Outdoors_Orders.Entity.OrdersEntity;

@SpringBootTest
class GoOutdoorsOrdersApplicationTests {

	@Test
	void mytest() {
		System.out.println("Testing in progress");
	}
// Get Operation
	@Test
	public void testgetUser() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Testcase is going on");
		final String baseUrl = "http://localhost:9005" + "/api5"+"/getorders";
		URI uri = new URI(baseUrl);
		ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
		assertEquals(200, result.getStatusCodeValue());
	}
//Put Operation
	@Test
	public void testUpdateEmployee() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Testing employee update");
		final String baseUrl = "http://localhost:9005/api5/gift/113";
		URI uri = new URI(baseUrl);
		OrdersEntity employeeToUpdate = new OrdersEntity(113, "bangalore", "discount", "23-07-16", "23-08-20");
		restTemplate.put(uri, employeeToUpdate);
	}
//	
	// Delete operation
			@Test
			public void testDeleteEmployee() throws URISyntaxException {
				RestTemplate restTemplate = new RestTemplate();
				System.out.println("Testing Orders deletion");
				final String baseUrl = "http://localhost:9005/api5/deleteorders/112"; // Replace with your actual delete endpoint
				URI uri = new URI(baseUrl);
				restTemplate.delete(uri);
				// Optionally, verify that the delete was successful.
			}
//			// Post Operation
			@Test
			public void testAddEmployeeSuccess() throws URISyntaxException
			{
				RestTemplate restTemplate = new RestTemplate();
				final String baseUrl = "http://localhost:9005/api5/addorders";
				URI uri = new URI(baseUrl);
				OrdersEntity user = new OrdersEntity(113, "bangalore", "vocher", "23-07-16", "23-08-20");
				HttpHeaders headers = new HttpHeaders();
				headers.set("X-COM-PERSIST", "true");
				HttpEntity<OrdersEntity> request = new HttpEntity<>(user, headers);
				ResponseEntity<String> result = restTemplate.postForEntity(uri, request, String.class);
				// Verify request succeed
				assertEquals(200, result.getStatusCodeValue());
			}
}


