package com.example.GO_Outdoors_Orders.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.GO_Outdoors_Orders.Entity.OrdersEntity;
import com.example.GO_Outdoors_Orders.Repository.OrdersRepo;

@CrossOrigin
@RestController
@RequestMapping("/api5")

public class ControllerOrders {
	@Autowired
	 
	OrdersRepo ordersRepo;
 
	@PostMapping("/addorders")
 
	public OrdersEntity createorders(@RequestBody OrdersEntity orders) {
 
		return ordersRepo.save(orders);
 
	}
 
	@PutMapping("/gift/{order_id}")
	public ResponseEntity<OrdersEntity> updateAddress(@PathVariable("order_id") int order_id,
			@RequestBody OrdersEntity ordersbypostman) {
 
		OrdersEntity orders = ordersRepo.findById(order_id)
				.orElseThrow(() -> new RuntimeException("Order details not exist with id :" + order_id));
 
		System.out.println("Is it to Gift?");
		String a = orders.getGift();
		if (a.equals("Yes")) {
			System.out.println("Update Address\n");
		} else {
			System.out.println("Retain the previous address!!!!\n");
		}
		orders.setOrder_address(ordersbypostman.getOrder_address());
 
		OrdersEntity updateAddress = ordersRepo.save(orders);
		return ResponseEntity.ok(updateAddress);
 
	}
 
	@GetMapping("/getorders")
 
	public List<OrdersEntity> getorders() {
 
		return ordersRepo.findAll(); // select * from product;
 
	}
 
	@DeleteMapping("/deleteorders/{order_id}")
 
	public String get(@PathVariable("order_id") int order_id)
 
	{
 
		ordersRepo.deleteById(order_id);
 
		System.out.println("orders details deleted\n");
 
		return "Is deleted";
 
	}
 
}