package com.example.GO_Outdoors_Orders.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Orders")

public class OrdersEntity {
	@Id
	
	int order_id;
	String order_address;
	String gift;
	String purchase_date;
	String delivery_date;
	
	public int getOrder_id() {
		return order_id;
	}


	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}


	public String getOrder_address() {
		return order_address;
	}


	public void setOrder_address(String order_address) {
		this.order_address = order_address;
	}


	public String getGift() {
		return gift;
	}


	public void setGift(String gift) {
		this.gift = gift;
	}


	public String getPurchase_date() {
		return purchase_date;
	}


	public void setPurchase_date(String purchase_date) {
		this.purchase_date = purchase_date;
	}


	public String getDelivery_date() {
		return delivery_date;
	}


	public void setDelivery_date(String delivery_date) {
		this.delivery_date = delivery_date;
	}


	public OrdersEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public OrdersEntity(int order_id, String order_address, String gift, String purchase_date, String delivery_date) {
		super();
		this.order_id = order_id;
		this.order_address = order_address;
		this.gift = gift;
		this.purchase_date = purchase_date;
		this.delivery_date = delivery_date;
	}
	
	@Override
	public String toString() {
		return "Orders [order_id=" + order_id + ", order_address=" + order_address + ", gift=" + gift
				+ ", purchase_date=" + purchase_date + ", delivery_date=" + delivery_date + "]";
	}
	

	
 
	

}
