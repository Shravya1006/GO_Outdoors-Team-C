package com.example.GO_Outdoors_Orders.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.GO_Outdoors_Orders.Entity.OrdersEntity;

public interface OrdersRepo extends JpaRepository<OrdersEntity,Integer> {
}


