package com.example.GO_Outdoors_Orders;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
@EnableMethodSecurity
@EnableWebSecurity
@SpringBootApplication
public class GoOutdoorsOrdersApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoOutdoorsOrdersApplication.class, args);
	}
	@Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http.csrf().disable()
                .authorizeHttpRequests()
                .requestMatchers("one","/api5/addorders").permitAll()
                .and()
                .authorizeHttpRequests().requestMatchers("/api5/**")
                .authenticated().and().formLogin().and().build();
    }

}
