package com.example.Lulu02_recap_Resistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lulu02RecapResistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
