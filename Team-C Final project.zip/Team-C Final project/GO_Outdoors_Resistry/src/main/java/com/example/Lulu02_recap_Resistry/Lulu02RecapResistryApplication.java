package com.example.Lulu02_recap_Resistry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
@EnableEurekaServer
@SpringBootApplication
public class Lulu02RecapResistryApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lulu02RecapResistryApplication.class, args);
	}

}
