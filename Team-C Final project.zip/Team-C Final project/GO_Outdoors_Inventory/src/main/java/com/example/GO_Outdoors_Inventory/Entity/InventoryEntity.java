package com.example.GO_Outdoors_Inventory.Entity;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Inventory")
public class InventoryEntity {
	@Id
	int inventory_id;
	int Quantity;
	public int getInventory_id() {
		return inventory_id;
	}
	public void setInventory_id(int inventory_id) {
		this.inventory_id = inventory_id;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
	public InventoryEntity(int inventory_id, int quantity) {
		super();
		this.inventory_id = inventory_id;
		Quantity = quantity;
	}
	public InventoryEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "InventoryEntity [inventory_id=" + inventory_id + ", Quantity=" + Quantity + "]";
	}
	
	

}
