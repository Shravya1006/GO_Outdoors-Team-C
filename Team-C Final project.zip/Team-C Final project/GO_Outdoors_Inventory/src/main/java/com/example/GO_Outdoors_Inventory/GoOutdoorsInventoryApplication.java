package com.example.GO_Outdoors_Inventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
@EnableMethodSecurity
@EnableWebSecurity
@SpringBootApplication
public class GoOutdoorsInventoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoOutdoorsInventoryApplication.class, args);
	}
	@Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http.csrf().disable()
                .authorizeHttpRequests()
                .requestMatchers("one","/api3/addInventoryProducts").permitAll()
                .and()
                .authorizeHttpRequests().requestMatchers("/api3/**")
                .authenticated().and().formLogin().and().build();
    }

}
