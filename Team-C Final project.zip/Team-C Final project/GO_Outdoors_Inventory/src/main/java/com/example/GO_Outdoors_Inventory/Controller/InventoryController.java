package com.example.GO_Outdoors_Inventory.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.GO_Outdoors_Inventory.Entity.InventoryEntity;
import com.example.GO_Outdoors_Inventory.Repository.InventoryRepository;
@CrossOrigin
@RestController
@RequestMapping("/api3")
public class InventoryController {
	@Autowired
	 
	InventoryRepository IR;
 
	@PostMapping("/addInventoryProducts") // End Point
 
	public InventoryEntity createinventory(@RequestBody InventoryEntity inventory) {
 
		return IR.save(inventory);
 
	}
 
	
 
	@GetMapping("/getInventoryProductList")
 
	public List<InventoryEntity> getinventory() {
 
		return IR.findAll();
 
	}
 
	// DeLETE data //
 
	@DeleteMapping("/deleteInventory/{id}")
 
	public String get(@PathVariable("id") int id) {
 
		IR.deleteById(id);
 
		System.out.println("Record 1 got deleted");
 
		return "Is deleted"; // select * from Order;
 
	}
 
	// Update data//
 
 
	@PutMapping("/updateinventory/{id}") //
 
	public ResponseEntity<InventoryEntity> updateInventory(@PathVariable("id") int id,
 
			@RequestBody InventoryEntity inventorybypostman) {
 
		InventoryEntity inventory = IR.findById(id)
 
				.orElseThrow(() -> new RuntimeException("User not exist with id :" + id));
 
		inventory.setInventory_id(inventorybypostman.getInventory_id());
 
		inventory.setQuantity(inventorybypostman.getQuantity());
 
		
		InventoryEntity updatedInventory = IR.save(inventory);
 
		return ResponseEntity.ok(updatedInventory);
 
	}

}
