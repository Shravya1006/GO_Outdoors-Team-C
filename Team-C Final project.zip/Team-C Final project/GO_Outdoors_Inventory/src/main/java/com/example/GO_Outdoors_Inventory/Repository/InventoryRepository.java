package com.example.GO_Outdoors_Inventory.Repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.example.GO_Outdoors_Inventory.Entity.InventoryEntity;

public interface InventoryRepository extends JpaRepository<InventoryEntity,Integer> {

}
