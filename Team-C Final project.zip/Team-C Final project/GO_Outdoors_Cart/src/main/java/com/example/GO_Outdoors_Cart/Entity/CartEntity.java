package com.example.GO_Outdoors_Cart.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Cart")
public class CartEntity {
	@Id
	int Product_id;
	String product_name;
	int Quantity;
	int size;
	String Color;
	String Address;
	String Estimated_delivery_date;
	public int getProduct_id() {
		return Product_id;
	}
	public void setProduct_id(int product_id) {
		Product_id = product_id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public String getColor() {
		return Color;
	}
	public void setColor(String color) {
		Color = color;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getEstimated_delivery_date() {
		return Estimated_delivery_date;
	}
	public void setEstimated_delivery_date(String estimated_delivery_date) {
		Estimated_delivery_date = estimated_delivery_date;
	}
	public CartEntity(int product_id, String product_name, int quantity, int size, String color, String address,
			String estimated_delivery_date) {
		super();
		Product_id = product_id;
		this.product_name = product_name;
		Quantity = quantity;
		this.size = size;
		Color = color;
		Address = address;
		Estimated_delivery_date = estimated_delivery_date;
	}
	public CartEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "CartEntity [Product_id=" + Product_id + ", product_name=" + product_name + ", Quantity=" + Quantity
				+ ", size=" + size + ", Color=" + Color + ", Address=" + Address + ", Estimated_delivery_date="
				+ Estimated_delivery_date + "]";
	}
	

}
