package com.example.GO_Outdoors_Cart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
@EnableMethodSecurity
@EnableWebSecurity
@SpringBootApplication
public class GoOutdoorsCartApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoOutdoorsCartApplication.class, args);
	}
	@Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http.csrf().disable()
                .authorizeHttpRequests()
                .requestMatchers("one","/api1/addproducts").permitAll()
                .and()
                .authorizeHttpRequests().requestMatchers("/api1/**")
                .authenticated().and().formLogin().and().build();
    }
 
 
	
	
	
	
	
 

 
	
	
}

