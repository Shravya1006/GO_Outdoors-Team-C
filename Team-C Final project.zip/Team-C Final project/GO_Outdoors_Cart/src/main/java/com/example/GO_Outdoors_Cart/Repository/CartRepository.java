package com.example.GO_Outdoors_Cart.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.GO_Outdoors_Cart.Entity.CartEntity;


public interface CartRepository extends JpaRepository<CartEntity,Integer> {

}
