package com.example.GO_Outdoors_Cart.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.GO_Outdoors_Cart.Entity.CartEntity;
import com.example.GO_Outdoors_Cart.Repository.CartRepository;



@CrossOrigin
@RestController
@RequestMapping("/api1")

public class CartCntroller {
	@Autowired
	CartRepository CR;
	@PostMapping("/addproducts") // End Point
	public CartEntity createproducts(@RequestBody CartEntity products) {
		return CR.save(products);
	}
 
	@GetMapping("/getproducts")
	public List<CartEntity> getproducts() {
 
		return CR.findAll();
	}
 
	
 
	// DeLETE data //
 
	@DeleteMapping("/deleteproducts/{product_id}")
 
	public String get(@PathVariable("product_id") int product_id) {
 
		CR.deleteById(product_id);
 
		System.out.println("Record 1 got deleted");
 
		return "Is deleted"; // select * from Order;
 
	}
	
	@PutMapping("/updateproducts/{product_id}") //
	 
	public ResponseEntity<CartEntity> updateCart(@PathVariable("product_id") int product_id,
			@RequestBody CartEntity cartbypostman) {
 
		CartEntity cart = CR.findById(product_id)
 
				.orElseThrow(() -> new RuntimeException("product not exist with id :" + product_id));
 
		cart.setProduct_id(cartbypostman.getProduct_id());
 
		cart.setProduct_name(cartbypostman.getProduct_name());
 
		CartEntity updatedCart = CR.save(cart);
 
		return ResponseEntity.ok(updatedCart);
 
	}


}
