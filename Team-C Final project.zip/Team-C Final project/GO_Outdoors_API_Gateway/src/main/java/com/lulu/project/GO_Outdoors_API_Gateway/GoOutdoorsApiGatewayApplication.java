package com.lulu.project.GO_Outdoors_API_Gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoOutdoorsApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoOutdoorsApiGatewayApplication.class, args);
	}

}
