package com.lulu.project.GO_Outdoors_API_Gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoOutdoorsApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
