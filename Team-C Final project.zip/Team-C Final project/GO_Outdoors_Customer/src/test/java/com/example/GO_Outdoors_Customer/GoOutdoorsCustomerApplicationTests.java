package com.example.GO_Outdoors_Customer;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.example.GO_Outdoors_Customer.Entity.CustomerEntity;


@SpringBootTest
class GoOutdoorsCustomerApplicationTests {


	@Test
	void mytest() {
		System.out.println("Testing in progress");
	}
// Get Operation
	@Test
	public void testgetUser() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Testcase is going on");
		final String baseUrl = "http://localhost:9003" + "/api8/Customer"+"/getproducts";
		URI uri = new URI(baseUrl);
		ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
		assertEquals(200, result.getStatusCodeValue());
	}
//Put Operation
	@Test
	public void testUpdateEmployee() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		System.out.println("Testing employee update");
		final String baseUrl = "http://localhost:9003/api8/Customer/updatecustomer/14";
		URI uri = new URI(baseUrl);
		CustomerEntity employeeToUpdate = new CustomerEntity(14, "Sanvi", "mandya", "asdfghj@gmail.com", "8790653456", "qwertyu", 87325);
		restTemplate.put(uri, employeeToUpdate);
	}
//	
	// Delete operation
			@Test
			public void testDeleteEmployee() throws URISyntaxException {
				RestTemplate restTemplate = new RestTemplate();
				System.out.println("Testing Orders deletion");
				final String baseUrl = "http://localhost:9003/api8/Customer/deleteproducts/13"; // Replace with your actual delete endpoint
				URI uri = new URI(baseUrl);
				restTemplate.delete(uri);
				// Optionally, verify that the delete was successful.
			}
//			// Post Operation
			@Test
			public void testAddEmployeeSuccess() throws URISyntaxException
			{
				RestTemplate restTemplate = new RestTemplate();
				final String baseUrl = "http://localhost:9003/api8/Customer/addproducts";
				URI uri = new URI(baseUrl);
				CustomerEntity user = new CustomerEntity(14, "manvi", "mandya", "asdfghj@gmail.com", "8790653456", "qwertyu", 87325);
				HttpHeaders headers = new HttpHeaders();
				headers.set("X-COM-PERSIST", "true");
				HttpEntity<CustomerEntity> request = new HttpEntity<>(user, headers);
				ResponseEntity<String> result = restTemplate.postForEntity(uri, request, String.class);
				// Verify request succeed
				assertEquals(200, result.getStatusCodeValue());
			}


}
