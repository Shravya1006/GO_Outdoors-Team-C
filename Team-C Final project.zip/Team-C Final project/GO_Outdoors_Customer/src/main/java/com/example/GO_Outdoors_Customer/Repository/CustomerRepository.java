package com.example.GO_Outdoors_Customer.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.GO_Outdoors_Customer.Entity.CustomerEntity;



public interface CustomerRepository extends JpaRepository<CustomerEntity,Integer>{

}
