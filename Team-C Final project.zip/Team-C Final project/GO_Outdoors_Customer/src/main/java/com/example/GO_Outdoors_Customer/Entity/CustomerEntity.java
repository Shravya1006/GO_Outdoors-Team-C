package com.example.GO_Outdoors_Customer.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="customer")
public class CustomerEntity {
	@Id
	int Customer_id;
	String Customer_Name;
	String customer_address;
	String email;
	String phone_no;
	String password;
	int pincode;
	public int getCustomer_id() {
		return Customer_id;
	}
	public void setCustomer_id(int customer_id) {
		Customer_id = customer_id;
	}
	public String getCustomer_Name() {
		return Customer_Name;
	}
	public void setCustomer_Name(String customer_Name) {
		Customer_Name = customer_Name;
	}
	public String getCustomer_address() {
		return customer_address;
	}
	public void setCustomer_address(String customer_address) {
		this.customer_address = customer_address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public CustomerEntity(int customer_id, String customer_Name, String customer_address, String email, String phone_no,
			String password, int pincode) {
		super();
		Customer_id = customer_id;
		Customer_Name = customer_Name;
		this.customer_address = customer_address;
		this.email = email;
		this.phone_no = phone_no;
		this.password = password;
		this.pincode = pincode;
	}
	public CustomerEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "CustomerEntity [Customer_id=" + Customer_id + ", Customer_Name=" + Customer_Name + ", customer_address="
				+ customer_address + ", email=" + email + ", phone_no=" + phone_no + ", password=" + password
				+ ", pincode=" + pincode + "]";
	}

	

}
