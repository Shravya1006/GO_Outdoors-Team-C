package com.example.GO_Outdoors_Customer.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.GO_Outdoors_Customer.Entity.CustomerEntity;
import com.example.GO_Outdoors_Customer.Repository.CustomerRepository;
@CrossOrigin
@RestController
@RequestMapping("/api8/Customer")
public class CustomerController {
	@Autowired
	CustomerRepository CR;
 
	@PostMapping("/addproducts") // End Point
	public CustomerEntity createproducts(@RequestBody CustomerEntity products) {
		return CR.save(products);
	}
 
	@GetMapping("/getproducts")
	public List<CustomerEntity> getproducts() {
 
		return CR.findAll();
	}
 
	
 
	// DeLETE data //
 
	@DeleteMapping("/deleteproducts/{product_id}")
 
	public String get(@PathVariable("product_id") int product_id) {
 
		CR.deleteById(product_id);
 
		System.out.println("Record 1 got deleted");
 
		return "Is deleted"; // select * from Order;
 
	}
 
	
 
	@PutMapping("/updatecustomer/{customer_id}")

	public ResponseEntity<CustomerEntity> updateCustomer(@PathVariable("customer_id") int customer_id,
			@RequestBody CustomerEntity customerbypostman) {

		CustomerEntity customer = CR.findById(customer_id)
				.orElseThrow(() -> new RuntimeException("Customer does not exist with id :" + customer_id));

		customer.setCustomer_id(customerbypostman.getCustomer_id());

		customer.setCustomer_Name(customerbypostman.getCustomer_Name());

		customer.setCustomer_address(customerbypostman.getCustomer_address());

		customer.setEmail(customerbypostman.getEmail());

		customer.setPhone_no(customerbypostman.getPhone_no());

		customer.setPassword(customerbypostman.getPassword());

		customer.setPincode(customerbypostman.getPincode());

		CustomerEntity updatedCustomer = CR.save(customer);

		return ResponseEntity.ok(updatedCustomer);

	}
}
 
	
 



